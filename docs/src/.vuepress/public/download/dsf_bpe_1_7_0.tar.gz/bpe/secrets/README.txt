Modify with generated password:

db_liquibase.password -> recomended min. 32 characters
db_user.password -> recomended min. 16 characters
db_user_camunda.password -> recommended min. 16 characters


Add files (chmod: 440, chown: bpe:docker):

client_certificate.pem -> Client certificate file from D-TRUST, GÈANT TCS or HARICA (DFN)
client_certificate_private_key.pem -> Client certificate private-key (can be encrypted)
client_certificate_private_key.pem.password -> File with password for client certificate private-key (ommit file if not encrypted, remove corresponding entries from docker-compose -> lines 13,41,99,100)


Add other certificates, keys or passwords in the same way using docker secrets